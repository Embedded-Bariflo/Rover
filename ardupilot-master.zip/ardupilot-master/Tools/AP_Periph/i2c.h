bool i2c_transfer(uint8_t address,
                  const uint8_t *send, uint32_t send_len,
                  uint8_t *recv, uint32_t recv_len);
