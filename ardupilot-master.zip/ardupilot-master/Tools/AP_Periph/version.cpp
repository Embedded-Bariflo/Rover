#define FORCE_VERSION_H_INCLUDE
#include "version.h"
#include <AP_Common/AP_FWVersionDefine.h>
#undef FORCE_VERSION_H_INCLUDE