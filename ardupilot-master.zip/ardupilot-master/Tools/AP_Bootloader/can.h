void can_start();
void can_update();
void can_set_node_id(uint8_t node_id);
bool can_check_update(void);
