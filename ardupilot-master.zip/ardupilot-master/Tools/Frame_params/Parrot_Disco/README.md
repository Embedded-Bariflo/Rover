Please see https://ardupilot.org/plane/docs/airframe-disco.html for
more information on setting up a Parrot Disco
