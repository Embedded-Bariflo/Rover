# Support

Our GitHub isn't the appropriate place for getting support on ArduPilot usage. Please look below for the two options you have available for getting help solving any issue you have using ArduPilot.

If you are having trouble with **code development** please ask in our Gitter: http://gitter.im/ArduPilot/ardupilot

## Free support

If you want free, community-based support, please post in our forum: http://discuss.ardupilot.org

## Commercial support

If you need fast, paid support, please consult our wiki page and choose a company: http://ardupilot.org/ardupilot/docs/common-commercial-support.html
